#ifndef __TIME_H
#define __TIME_H

#include "stm32f10x.h"

void TIM1_Init(int16_t Tcon,uint16_t psc);
void TIM2_Init(int16_t Tcon,uint16_t psc);
void TIM3_Init(int16_t Tcon,uint16_t psc);
void TIM4_Init(int16_t Tcon,uint16_t psc);
void TIM1_4_Init(void);

#endif
