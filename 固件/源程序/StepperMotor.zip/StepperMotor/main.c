/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/main.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */  

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "main.h"
#include "led.h"
#include "motor.h"
#include "usart.h"
#include "time.h"

/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)



/* Private functions ---------------------------------------------------------*/
void delay(uint16_t t)
{
	int i, j;
  for (i = 0; i < 72; i++) {
		for (j = 0; j < t; j++);
	}
}

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{
	uint16_t i;
	float cmd_val;
	
	// initialize
	led_init();
	motor_init();
	usart_init();
	TIM1_4_Init();//��ʱ����ʼ��
	
	printf("\r\n\r\nStart...\r\n");
	
  /* Infinite loop */
  while (1) {
		if (RxDone == 1) {
			led1_set(1);  // led on
			cmd_val = 0;
			for (i=0; i<RxPos; i++) {
				if (RxBuf[i] == ' ') {
					cmd_val = (float)atof(RxBuf + i + 1);
					break;
				}
			}
			printf("cmd_val %f\r\n", cmd_val);
			
			switch(RxBuf[0]) {
				// acceleration
				case 'A':
					Acce[RxBuf[1]-'0'] = (uint32_t)(cmd_val * MicroStep[RxBuf[1]-'0'] * STEPS_PER_ROUND + 0.5);
					StepsToMaxSpeed[RxBuf[1]-'0'] = (uint32_t)(MaxSpeed[RxBuf[1]-'0'] * MaxSpeed[RxBuf[1]-'0'] / 2.0 / Acce[RxBuf[1]-'0'] + 0.5);
					AcceRoot[RxBuf[1]-'0'] = (uint32_t)(sqrt(Acce[RxBuf[1]-'0']) + 0.5);
		  	  break;
				
				// deceleration
				case 'D':
					Dece[RxBuf[1]-'0'] = (uint32_t)(cmd_val * MicroStep[RxBuf[1]-'0'] * STEPS_PER_ROUND + 0.5);
					StepsToMinSpeed[RxBuf[1]-'0'] = (uint32_t)(MaxSpeed[RxBuf[1]-'0'] * MaxSpeed[RxBuf[1]-'0'] / 2.0 / Dece[RxBuf[1]-'0'] + 0.5);
					DeceRoot[RxBuf[1]-'0'] = (uint32_t)(sqrt(Dece[RxBuf[1]-'0']) + 0.5);
		  	  break;
				
				// max speed
				case 'S':
					MaxSpeed[RxBuf[1]-'0'] = (uint32_t)(cmd_val * MicroStep[RxBuf[1]-'0'] * STEPS_PER_ROUND / 60.0 + 0.5);
					StepsToMaxSpeed[RxBuf[1]-'0'] = (uint32_t)(MaxSpeed[RxBuf[1]-'0'] * MaxSpeed[RxBuf[1]-'0'] / 2.0 / Acce[RxBuf[1]-'0'] + 0.5);
					StepsToMinSpeed[RxBuf[1]-'0'] = (uint32_t)(MaxSpeed[RxBuf[1]-'0'] * MaxSpeed[RxBuf[1]-'0'] / 2.0 / Dece[RxBuf[1]-'0'] + 0.5);
					MinAcce[RxBuf[1]-'0'] = (uint32_t)(MaxSpeed[RxBuf[1]-'0'] * MaxSpeed[RxBuf[1]-'0'] / 2.0 / MOTOR_TABLE_SIZE + 0.5);
		  	  break;
				
				// microstep
				case 'U':
					MicroStep[RxBuf[1]-'0'] = cmd_val;
					break;
				
				// test all motors
				case 'T':
					if (cmd_val == 0)
						cmd_val = 64000;
					motor_test((int32_t)cmd_val);
					break;
					
				// lookup table
				case 'L':
					if (RxBuf[1] == 'G')
						motor_generate_table();
					else
						motor_verify_table();
					break;
				case 'M':
					for (i = 0; i<MOTOR_NUM; i++)
						Step[i] = 0;
					i = 0;
					while (RxBuf[i] != 0) {
						if (RxBuf[i] == 'M'){
							Step[RxBuf[i + 1]-'0'] = atoi(RxBuf + i + 2);
						}
						i++;
					}
					motor_run();
					break;
				// help message
				case '?':
					printf("                       X(0)   Y(1)   Z(2)   A(3)\r\n");
					printf("Max Speed(RPM):      %.2f %.2f %.2f %.2f\r\n", MaxSpeed[0]*60.0/STEPS_PER_ROUND/MicroStep[0], MaxSpeed[1]*60.0/STEPS_PER_ROUND/MicroStep[1], MaxSpeed[2]*60.0/STEPS_PER_ROUND/MicroStep[2], MaxSpeed[3]*60.0/STEPS_PER_ROUND/MicroStep[3]);
					printf("Max Speed(steps/s):  %6d %6d %6d %6d\r\n", MaxSpeed[0], MaxSpeed[1], MaxSpeed[2], MaxSpeed[3]);
					printf("Max Speed(us/step):  %6d %6d %6d %6d\r\n", 1000000 / MaxSpeed[0], 1000000 / MaxSpeed[1], 1000000 / MaxSpeed[2], 1000000 / MaxSpeed[3]);
					printf("Acce(rounds/s^2):    %.4f %.4f %.4f %.4f\r\n", Acce[0]*1.0/STEPS_PER_ROUND/MicroStep[0], Acce[1]*1.0/STEPS_PER_ROUND/MicroStep[1], Acce[2]*1.0/STEPS_PER_ROUND/MicroStep[2], Acce[3]*1.0/STEPS_PER_ROUND/MicroStep[3]);
					printf("Acce(steps/s^2):     %6d %6d %6d %6d\r\n", Acce[0], Acce[1], Acce[2], Acce[3]);
					printf("AcceRoot(steps/s^2): %6d %6d %6d %6d\r\n", AcceRoot[0], AcceRoot[1], AcceRoot[2], AcceRoot[3]);
					printf("MinAcce(steps/s^2):  %6d %6d %6d %6d\r\n", MinAcce[0], MinAcce[1], MinAcce[2], MinAcce[3]);
					printf("Dece(rounds/s^2):    %.4f %.4f %.4f %.4f\r\n", Dece[0]*1.0/STEPS_PER_ROUND/MicroStep[0], Dece[1]*1.0/STEPS_PER_ROUND/MicroStep[1], Dece[2]*1.0/STEPS_PER_ROUND/MicroStep[2], Dece[3]*1.0/STEPS_PER_ROUND/MicroStep[3]);
					printf("Dece(steps/s^2):     %6d %6d %6d %6d\r\n", Dece[0], Dece[1], Dece[2], Dece[3]);
					printf("MinDece(Steps/s^2):  %6d %6d %6d %6d\r\n", MinAcce[0], MinAcce[1], MinAcce[2], MinAcce[3]);
					printf("Microstep:           %6d %6d %6d %6d\r\n", MicroStep[0], MicroStep[1], MicroStep[2], MicroStep[3]);
					printf("StepsToMax:          %6d %6d %6d %6d\r\n", StepsToMaxSpeed[0], StepsToMaxSpeed[1], StepsToMaxSpeed[2], StepsToMaxSpeed[3]);
					printf("StepsToZero:         %6d %6d %6d %6d\r\n", StepsToMinSpeed[0], StepsToMinSpeed[1], StepsToMinSpeed[2], StepsToMinSpeed[3]);
					printf("Step:                %6d %6d %6d %6d\r\n", Step[0], Step[1], Step[2], Step[3]);
					printf("Step Count:          %6d %6d %6d %6d\r\n", step_count[0], step_count[1], step_count[2], step_count[3]);
					break;
			}  // end of switch
			
			RxDone = 0;
			RxPos = 0;
			led1_set(0);  // led off
		}  // if RxDone

  }  // while(1)
}

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART */
  USART_SendData(USART1, (uint8_t) ch);

  /* Loop until the end of transmission */
  while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET) {}

  return ch;
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
