#ifndef __FLASH_H
#define __FLASH_H

#include "stm32f10x.h"

#define FLASH_START_ADDR	0x08000000
#define FLASH_PAGE_SIZE		1024

uint32_t flash_read(uint32_t addr);
uint8_t flash_erase(uint32_t addr, uint32_t page_num);

#endif
