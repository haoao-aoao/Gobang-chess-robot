#include "led.h"

// initialize GPIOs for LED
void led_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	// enable clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	// PB0~15 for motors
	GPIO_InitStructure.GPIO_Pin = LED_PIN3 | LED_PIN8 | LED_PIN1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(LED_PORT, &GPIO_InitStructure);
}

// set led to on/off
void led1_set(uint8_t value)
{
	if (value == 0)
		GPIO_SetBits(LED_PORT, LED_PIN3);
	else
		GPIO_ResetBits(LED_PORT, LED_PIN3);
}

void led2_set(uint8_t value)
{
	if (value == 0)
		GPIO_SetBits(LED_PORT, LED_PIN8);
	else
		GPIO_ResetBits(LED_PORT, LED_PIN8);
}

void led3_set(uint8_t value)
{
	if (value == 0)
		GPIO_SetBits(LED_PORT, LED_PIN1);
	else
		GPIO_ResetBits(LED_PORT, LED_PIN1);
}