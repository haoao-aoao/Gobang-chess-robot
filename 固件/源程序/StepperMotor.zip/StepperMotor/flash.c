#include <stdio.h>
#include "flash.h"

// reference: 
//   1. https://www.cnblogs.com/pertor/p/9484663.html
//   2. https://www.21ic.com/tougao/article/3032.html

// STM32F103C8T6: 64K Flash (1K / Page)

uint32_t flash_read(uint32_t addr)
{
	uint32_t data;
	data = *(uint32_t *)addr;
	return data;
}

uint8_t flash_erase(uint32_t addr, uint32_t page_num)
{
	uint8_t i;

  for(i = 0; i < page_num; i++) {
		if (FLASH_ErasePage(addr + i * FLASH_PAGE_SIZE) != FLASH_COMPLETE)
      return 0;
  }

  return 1;
}
