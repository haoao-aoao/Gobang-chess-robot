#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"

// GPIO pins for motor
#define MOTOR_NUM			4
#define MOTOR_PORT		GPIOB
#define MOTOR_STEP0		GPIO_Pin_0
#define MOTOR_DIR0		GPIO_Pin_1
#define MOTOR_STEP1		GPIO_Pin_10 | GPIO_Pin_13
#define MOTOR_DIR1		GPIO_Pin_11 | GPIO_Pin_14
#define MOTOR_STEP2		GPIO_Pin_3
#define MOTOR_DIR2		GPIO_Pin_4
#define MOTOR_STEP3		GPIO_Pin_6
#define MOTOR_DIR3		GPIO_Pin_7

// 8192 lookup table (size: 8K*4 bytes)
#define MOTOR_TABLE_SIZE		8192
#define MOTOR_TABLE_ADDR		0x08008000  // FLASH_START_ADDR + 64K / 2

// motion control
#define MAXSPEED0  			400		// rpm
#define MAXSPEED1  			350		// rpm
#define MAXSPEED2  			300		// rpm
#define MAXSPEED3  			250		// rpm
#define ACCE0      			80		// round/min^2.  reach max speed in ? seconds
#define ACCE1      			70		// round/min^2.  reach max speed in ? seconds
#define ACCE2      			150		// round/min^2.  reach max speed in ? seconds
#define ACCE3      			450		// round/min^2.  reach max speed in ? seconds
#define DECE0      			100		// round/min^2.  stop from max speed in ? seconds
#define DECE1      			88		// round/min^2.  stop from max speed in ? seconds
#define DECE2      			200		// round/min^2.  stop from max speed in ? seconds
#define DECE3      			500		// round/min^2.  stop from max speed in ? seconds
#define MICROSTEP0			1			// microstep = 1
#define MICROSTEP1			2			// microstep = 4
#define MICROSTEP2			8		// microstep = 16
#define MICROSTEP3			32		// microstep = 64
#define STEPS_PER_ROUND	200		// 200 full steps / round

// motor state
#define MOTOR_STOP			0
#define MOTOR_ACCE			1
#define MOTOR_RUN				2
#define MOTOR_DECE			3

extern uint16_t MicroStep[MOTOR_NUM];				// microsteps
extern uint32_t MaxSpeed[MOTOR_NUM];				// steps/sec
extern uint32_t Acce[MOTOR_NUM];						// steps/sec^2
extern uint32_t Dece[MOTOR_NUM];						// steps/sec^2
extern uint32_t StepsToMaxSpeed[MOTOR_NUM];	// steps
extern uint32_t StepsToMinSpeed[MOTOR_NUM];	// steps
extern uint32_t MinAcce[MOTOR_NUM];					// steps/sec^2
extern uint32_t MinDece[MOTOR_NUM];					// steps/sec^2
extern uint32_t AcceRoot[MOTOR_NUM];
extern uint32_t DeceRoot[MOTOR_NUM];
extern volatile uint8_t MotorState[MOTOR_NUM];

extern int32_t Step[MOTOR_NUM];
extern uint32_t StepCount[MOTOR_NUM];//��ȷ�����жϵĴ���
extern uint32_t step_count[MOTOR_NUM];//ʵ�ʽ����жϵĴ���

extern uint32_t max_s_lim[MOTOR_NUM];
extern uint32_t accel_lim[MOTOR_NUM];
extern uint32_t decel_lim[MOTOR_NUM];
extern uint32_t decel_start[MOTOR_NUM];

void motor_init(void);
void motor_set_dir(uint8_t id, uint8_t dir);
void motor_set_step(uint8_t id, uint8_t dir);
void motor_test(int32_t val);
void motor_generate_table(void);
uint8_t motor_verify_table(void);

void motor_run(void);
void MY_Handler(uint8_t NUM);
#endif
