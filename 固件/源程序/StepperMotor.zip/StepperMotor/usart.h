#ifndef __USART_H
#define __USART_H

#include "stm32f10x.h"

#define RXSIZE 64

extern char RxBuf[RXSIZE];
extern __IO uint8_t RxPos;
extern __IO uint8_t RxDone;

void usart_init(void);

#endif
