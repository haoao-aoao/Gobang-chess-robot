#include <stdio.h>
#include <math.h>
#include "main.h"
#include "motor.h"
#include "flash.h"
#include "led.h"

uint16_t MicroStep[MOTOR_NUM];				// microsteps
uint32_t MaxSpeed[MOTOR_NUM];					// steps/sec
uint32_t Acce[MOTOR_NUM];							// steps/sec^2
uint32_t Dece[MOTOR_NUM];							// steps/sec^2

uint32_t StepsToMaxSpeed[MOTOR_NUM];	// steps
uint32_t StepsToMinSpeed[MOTOR_NUM];	// steps
uint32_t MinAcce[MOTOR_NUM];					// steps/sec^2
uint32_t MinDece[MOTOR_NUM];					// steps/sec^2
uint32_t AcceRoot[MOTOR_NUM];
uint32_t DeceRoot[MOTOR_NUM];

uint32_t max_s_lim[MOTOR_NUM];
uint32_t accel_lim[MOTOR_NUM];
uint32_t decel_lim[MOTOR_NUM];
uint32_t decel_start[MOTOR_NUM];

int32_t Step[MOTOR_NUM];  // total steps to run
uint32_t StepCount[MOTOR_NUM];
uint32_t step_count[MOTOR_NUM];
volatile uint8_t MotorState[MOTOR_NUM];


// initialize GPIOs for motor
void motor_init(void)
{
	uint16_t i;
	GPIO_InitTypeDef GPIO_InitStructure;
	
	// enable clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	// use PB3,PB4,PA13,PA14,PA15 as GPIOs
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE); 
	
	// PB0~15 for motors
	GPIO_InitStructure.GPIO_Pin = MOTOR_STEP0 | MOTOR_DIR0 | MOTOR_STEP1 | MOTOR_DIR1 | MOTOR_STEP2 | MOTOR_DIR2 | MOTOR_STEP3 | MOTOR_DIR3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(MOTOR_PORT, &GPIO_InitStructure);
	
	// motion control parameters
	MicroStep[0] = MICROSTEP0;
	MicroStep[1] = MICROSTEP1;
	MicroStep[2] = MICROSTEP2;
	MicroStep[3] = MICROSTEP3;
	MaxSpeed[0] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP0 * MAXSPEED0 / 60.0 + 0.5);
	MaxSpeed[1] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP1 * MAXSPEED1 / 60.0 + 0.5);
	MaxSpeed[2] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP2 * MAXSPEED2 / 60.0 + 0.5);
	MaxSpeed[3] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP3 * MAXSPEED3 / 60.0 + 0.5);
	Acce[0] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP0 * ACCE0 / 60.0 + 0.5);
	Acce[1] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP1 * ACCE1 / 60.0 + 0.5);
	Acce[2] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP2 * ACCE2 / 60.0 + 0.5);
	Acce[3] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP3 * ACCE3 / 60.0 + 0.5);
	Dece[0] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP0 * DECE0 / 60.0 + 0.5);
	Dece[1] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP1 * DECE1 / 60.0 + 0.5);
	Dece[2] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP2 * DECE2 / 60.0 + 0.5);
	Dece[3] = (uint32_t)(STEPS_PER_ROUND * MICROSTEP3 * DECE3 / 60.0 + 0.5);
	
	step_count[0] = 0;
	step_count[1] = 0;
	step_count[2] = 0;
	step_count[3] = 0;
	for (i=0; i<MOTOR_NUM; i++) {
		StepsToMaxSpeed[i] = (uint32_t)(MaxSpeed[i] * MaxSpeed[i] / 2.0 / Acce[i] + 0.5);
		StepsToMinSpeed[i] = (uint32_t)(MaxSpeed[i] * MaxSpeed[i] / 2.0 / Dece[i] + 0.5);
		MinAcce[i] = (uint32_t)(MaxSpeed[i] * MaxSpeed[i] / 2.0 / MOTOR_TABLE_SIZE + 0.5);
		MotorState[i] = MOTOR_STOP;
		AcceRoot[i] = (uint32_t)(sqrt(Acce[i]) + 0.5);
		DeceRoot[i] = (uint32_t)(sqrt(Dece[i]) + 0.5);
	}
}

// set motor DIR pin
void motor_set_dir(uint8_t id, uint8_t dir)
{
	switch(id) {
		case 0:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_DIR0);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_DIR0);
			break;
			
		case 1:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_DIR1);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_DIR1);
			break;
			
		case 2:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_DIR2);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_DIR2);
			break;
			
		case 3:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_DIR3);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_DIR3);
			break;
	}
}

// set motor STEP pin
void motor_set_step(uint8_t id, uint8_t dir)
{
	switch(id) {
		case 0:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_STEP0);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_STEP0);
			break;
			
		case 1:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_STEP1);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_STEP1);
			break;
			
		case 2:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_STEP2);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_STEP2);
			break;
			
		case 3:
			if (dir == 0)
				GPIO_ResetBits(MOTOR_PORT, MOTOR_STEP3);
			else
				GPIO_SetBits(MOTOR_PORT, MOTOR_STEP3);
			break;
	}
}

// test all motors
void motor_test(int32_t val)
{
	uint16_t i, j;
	int32_t count;
	
	if (val <= 0) {
		printf("val is less than 0\r\n");
		return;
	}
	
	// clockwise
	printf("clockwise\r\n");
	for (i = 0; i < MOTOR_NUM; i++)
		motor_set_dir(i, 0);
	count = 0;
	i = 500;
	while (1) {
		for (j = 0; j < MOTOR_NUM; j++)
			motor_set_step(j, 0);
		delay(i);
		for (j = 0; j < MOTOR_NUM; j++)
			motor_set_step(j, 1);
		delay(i);
		
		if (i > 5)
			i--;
		count++;
		if (count > val)
			break;
	}

	// counter clockwise
	printf("counter clockwise\r\n");
	for (i = 0; i < MOTOR_NUM; i++)
		motor_set_dir(i, 1);
	count = 0;
	i = 500;
	while (1) {
		for (j = 0; j < MOTOR_NUM; j++)
			motor_set_step(j, 0);
		delay(i);
		for (j = 0; j < MOTOR_NUM; j++)
			motor_set_step(j, 1);
		delay(i);

		if (i > 5)
			i--;
		count++;
		if (count > val)
			break;
	}	
}

// Generate the lookup table for linear speed control.���������ٶȿ��Ʊ� 
// Table size is 32K (MOTORTABLESIZE * 4).
// uint32_t value = sqrt(n+1) - sqrt(n).    0 <= n < MOTORTABLESIZE(default is 8K)
void motor_generate_table(void)
{
	uint32_t i;
	uint32_t addr;
	uint32_t value;

	// write table. table size = sizeof(float) * 8K = 32K bytes
	printf("writing motor lookup table\r\n");
	FLASH_Unlock();
	flash_erase(MOTOR_TABLE_ADDR, MOTOR_TABLE_SIZE * sizeof(uint32_t) / FLASH_PAGE_SIZE);  // erase 32 pages started from 0x0800_8000
	
	addr = MOTOR_TABLE_ADDR;
	for (i=0; i<MOTOR_TABLE_SIZE; i++) {
		value = (uint32_t)( sqrt(2.0) * (sqrt(i+1) - sqrt(i)) * 1000000.0 + 0.5 );
		if (i % 256 == 0)
			printf("  %d: value %d\r\n", i, value);
		if (FLASH_ProgramWord(addr, value) == FLASH_COMPLETE) {
			addr += 4;
		}
		else {
			printf("motor_generate_table() failed!\r\n");
			FLASH_Lock();
			return;
		}
	}

	FLASH_Lock();
}

uint8_t motor_verify_table(void)
{
	uint32_t i, j;
	uint32_t addr;
	uint32_t value, value2;
	uint8_t err;
	uint8_t num;
	
	err = 0;
	addr = MOTOR_TABLE_ADDR;
	num = MOTOR_TABLE_SIZE * sizeof(uint32_t) / FLASH_PAGE_SIZE;
	for (i=0; i<num; i++) {
		j = i * FLASH_PAGE_SIZE / sizeof(uint32_t);
		value = (uint32_t)( sqrt(2.0) * (sqrt(j+1) - sqrt(j)) * 1000000.0 + 0.5 );
		value2 = flash_read(addr);
		if (value == value2) {
			printf("addr: 0x%x; value: %d, %d; passed\r\n", addr, value, value2);
		}
		else {
			printf("addr: 0x%x; value: %d, %d; failed\r\n", addr, value, value2);
			err = 1;
		}
		addr += FLASH_PAGE_SIZE;
	}	
	
	if (err == 0) {
		printf("motor_verify_talbe() passed!\r\n");
		return 1;
	}

	printf("motor_verify_talbe() failed!\r\n");
	return 0;
}


/*
Step:����
Acce:���ٶ�
Dece:���ٶ�
MaxSpeed:����ٶ�
*/
void motor_run()
{
	//�ﵽ����ٶ�ǰ�Ĳ���
  //unsigned int max_s_lim;
  //! ���Ǳ��뿪ʼ����֮ǰ�Ĳ��������accelû�дﵽ����ٶȣ�
  //unsigned int accel_lim;
	uint8_t i;
	uint32_t addr = MOTOR_TABLE_ADDR;
	uint32_t value;
	uint32_t step_delay;
	uint32_t acce_lim; // ���ٲ���������û�дﵽ����ٶȣ�
	
	for(i=0; i<MOTOR_NUM; i++) {
		if(Step[i] == 0) continue;
		if(Step[i] < 0) {
			Step[i] = -Step[i];
			motor_set_dir(i, 0);//���õ��ѡ����
		}else if(Step[i] > 0) {
			motor_set_dir(i, 1);//���õ��ѡ����
		}
		
		if(Step[i] != 0){
			//���㵽������ٶ�ǰ��Ҫ�Ĳ���((MaxSpeed*MaxSpeed)/2*Acce)
			max_s_lim[i] = (uint32_t)(MaxSpeed[i]*MaxSpeed[i]/ 2 / Acce[i]+0.5);
			if(max_s_lim[i] == 0){
				max_s_lim[i] = 1;
			}
			
			//���㿪ʼ���ٵĲ���
			// n1 = (n1+n2)decel / (accel + decel)
			acce_lim = ((long)Step[i]*Dece[i]) / (Acce[i] + Dece[i]);
			if(acce_lim <= max_s_lim[i]) {
				decel_lim[i] = Step[i] - acce_lim;
				max_s_lim[i] = acce_lim;
			}else {
				decel_lim[i] = (long)(max_s_lim[i] * Acce[i]) / Dece[i];
			}
			//printf("max_s_lim:%d  acce_lim:%d\r\n",max_s_lim[i],acce_lim);

			
			//������ٿ�ʼ��λ��
			decel_start[i] = Step[i] - decel_lim[i];
			//����ȫ�ٵĲ���
			accel_lim[i] = Step[i] - max_s_lim[i] - decel_lim[i];
			
			//�ı�����״̬
			MotorState[i] = MOTOR_ACCE;
			
			//�����һ����STEP�ź�
			value = flash_read(addr);
			step_delay = value / AcceRoot[i] / 2;
			
			printf("Move%d %d: %6d %6d %6d | %d\r\n", i, Step[i], max_s_lim[i], accel_lim[i], decel_lim[i], step_delay);
		}
	}//for
	
	
	for(i = 0; i < MOTOR_NUM; i++) {
		if(Step[i] > 0){
			if(i == 0){
				TIM1->CR1 |= 0x0001;
			}else if(i == 1){
				TIM2->CR1 |= 0x0001;
			}else if(i == 2){
				TIM3->CR1 |= 0x0001;
			}else{
				TIM4->CR1 |= 0x0001;
			}
		}
	}
}

void MY_Handler(uint8_t NUM)
{

	uint32_t addr = MOTOR_TABLE_ADDR;
	uint32_t value = 0;
	switch(MotorState[NUM]) {
		case MOTOR_STOP: 
			printf("count:%d Step:%d Done!\r\n",step_count[NUM],NUM);
			step_count[NUM] = 0;
			//ֹͣ��ʱ��
			if(NUM == 0){
				TIM1->CR1 &= 0xFFFE;
			}else if(NUM == 1){
				TIM2->CR1 &= 0xFFFE;
			}else if(NUM == 2){
				TIM3->CR1 &= 0xFFFE;
			}else{
				TIM4->CR1 &= 0xFFFE;
			}
			break;
		
		case MOTOR_ACCE:
			if(step_count[NUM] % 2 == 0){
				motor_set_step(NUM, 0);
			}else{
				motor_set_step(NUM, 1);
			}
			
			addr = MOTOR_TABLE_ADDR + step_count[NUM]/2 * 4;//�����ַ
			value = flash_read(addr) / AcceRoot[NUM] / 2;
			
			if(value > 65535) {
				value = 65535;
			}
			if(NUM == 0){
				TIM1->ARR = value;//���ö�ʱ������
			}else if(NUM == 1){
				TIM2->ARR = value;//���ö�ʱ������
			}else if(NUM == 2){
				TIM3->ARR = value;//���ö�ʱ������
			}else{
				TIM4->ARR = value;//���ö�ʱ������
			}
			step_count[NUM]++;
			if(step_count[NUM] >= decel_start[NUM]*2) {
				MotorState[NUM] = MOTOR_DECE;
			}else if(step_count[NUM] >= max_s_lim[NUM]*2) {
				MotorState[NUM] = MOTOR_RUN;
			}
			break;
		
		case MOTOR_RUN:
			if(step_count[NUM] % 2 == 0){
				motor_set_step(NUM, 0);
			}else{
				motor_set_step(NUM, 1);
			}
			step_count[NUM]++;
			if(step_count[NUM] >= decel_start[NUM]*2) {
				MotorState[NUM] = MOTOR_DECE;
			}
			break;
		
		case MOTOR_DECE:
			if(step_count[NUM] % 2 == 0){
				motor_set_step(NUM, 0);
			}else{
				motor_set_step(NUM, 1);
			}
			addr = addr + (Step[NUM] - step_count[NUM]/2) * 4;//�����ַ
			value = flash_read(addr) / DeceRoot[NUM] / 2;
			if(value > 65535) {
				value = 65535;
			}
			if(NUM == 0){
				TIM1->ARR = value;//���ö�ʱ������
			}else if(NUM == 1){
				TIM2->ARR = value;//���ö�ʱ������
			}else if(NUM == 2){
				TIM3->ARR = value;//���ö�ʱ������
			}else{
				TIM4->ARR = value;//���ö�ʱ������
			}
			step_count[NUM]++;
			if(step_count[NUM] > Step[NUM]*2) {
				MotorState[NUM] = MOTOR_STOP;
			}
			break;	
	}
	
}
