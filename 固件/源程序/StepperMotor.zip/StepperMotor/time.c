#include "time.h"

void TIM1_Init(int16_t Tcon,uint16_t psc)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// TIM3 clock enable
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	
	// Enable the TIM3 gloabal Interrupt
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;  // tim1 interrupt
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  // priority
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  // sub priority
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  // irq channel enabled
	NVIC_Init(&NVIC_InitStructure);
	
	// Time base configuration: freq = APB1 / Prescaler * 2 / Period = 36M / 144 * 2 / 5000 = 1MHz
	TIM_TimeBaseStructure.TIM_Period = Tcon;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;//1��Ƶ
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;//
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
	
	// TIM1 enable counter
	//TIM_Cmd(TIM1, ENABLE);
	// TIM IT enable
	TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
}

void TIM2_Init(int16_t Tcon,uint16_t psc)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// TIM2 clock enable
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	
	// Enable the TIM2 gloabal Interrupt
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;  // tim2 interrupt
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  // priority
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  // sub priority
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  // irq channel enabled
	NVIC_Init(&NVIC_InitStructure);

	// Time base configuration: freq = APB1 / Prescaler * 2 / Period = 36M / 144 * 2 / 5000 = 1MHz
	TIM_TimeBaseStructure.TIM_Period = Tcon;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	
	// TIM2 enable counter
	//TIM_Cmd(TIM2, ENABLE);
	// TIM IT enable
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
}

void TIM3_Init(int16_t Tcon,uint16_t psc)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// TIM3 clock enable
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	// Enable the TIM3 gloabal Interrupt
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;  // tim3 interrupt
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  // priority
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  // sub priority
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  // irq channel enabled
	NVIC_Init(&NVIC_InitStructure);
	
	// Time base configuration: freq = APB2 / Prescaler  / Period = 72M / 144 / 5000 = 1MHz
	TIM_TimeBaseStructure.TIM_Period = Tcon;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;//1��Ƶ 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	// TIM3 enable counter
	//TIM_Cmd(TIM3, ENABLE);
	// TIM IT enable
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
}

void TIM4_Init(int16_t Tcon,uint16_t psc)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// TIM4 clock enable
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	
	// Enable the TIM4 gloabal Interrupt
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;  // tim4 interrupt
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  // priority
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  // sub priority
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  // irq channel enabled
	NVIC_Init(&NVIC_InitStructure);
	
	// Time base configuration: freq = APB1 / Prescaler * 2 / Period = 36M / 144 * 2 / 5000 = 1MHz
	TIM_TimeBaseStructure.TIM_Period = Tcon;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
	
	// TIM4 enable counter
	//TIM_Cmd(TIM4, ENABLE);
	// TIM IT enable
	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
}

//��ʼ��4����ʱ��
void TIM1_4_Init(void)
{
	TIM1_Init(5000-1,72-1);
	TIM2_Init(5000-1,72-1);
	TIM3_Init(5000-1,72-1);
	TIM4_Init(5000-1,72-1);
}


