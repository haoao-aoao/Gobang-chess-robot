#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"

// GPIO pins for LED
#define LED_PORT	GPIOA
#define LED_PIN3		GPIO_Pin_3
#define LED_PIN8		GPIO_Pin_8
#define LED_PIN1		GPIO_Pin_7

void led_init(void);
void led_set1(uint8_t value);
void led_set2(uint8_t value);
void led_set3(uint8_t value);
#endif
